## Yuzu

Yuzu provides to e-merchants solutions to improve their profitability. With this extension, YUZU will be able to collect data and showcase your promotional offers.

This extension allows you to fully use the Yuzu Platform.

Create your account on [MyYuzu](https://my.yuzu.co/register)