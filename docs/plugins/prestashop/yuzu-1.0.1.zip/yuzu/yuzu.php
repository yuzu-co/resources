<?php
/**
 * The MIT License (MIT)
 *
 * Copyright (c) 2014-2015 Yuzu
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author    Jonathan Martin <jonathan@yuzu.co>
 * @copyright 2014-2015 Yuzu
 * @license   MIT Licence
 */

if (!defined('_PS_VERSION_'))
	exit;

define('YUZU_MERCHANT_KEY', 'YUZU_MERCHANT_KEY');
define('YUZU_SECRET_KEY', 'YUZU_SECRET_KEY');
define('YUZU_CSS_ADD_TO_CART_PRODUCT', 'YUZU_CSS_ADD_TO_CART_PRODUCT');
define('YUZU_DISPLAY_ORDER_DETAIL', 'YUZU_DISPLAY_ORDER_DETAIL');
define('YUZU_DISPLAY_CHECKOUT_SUCCESS', 'YUZU_DISPLAY_CHECKOUT_SUCCESS');

class Yuzu extends Module
{
	private $api_url;
	private $yuzu_url;
	private $merchant_key;
	private $secret_key;

	public function __construct()
	{
		$this->name = 'yuzu';
		$this->tab = 'advertising_marketing';
		$this->version = '1.0.1';
		$this->author = 'Yuzu';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.4', 'max' => '1.6');
		$this->bootstrap = true;
		$this->template_directory = dirname(__FILE__).'/views/templates/admin/';
		$this->template_prefix = '';

		parent::__construct();

		$this->displayName = $this->l('Yuzu');
		$this->description = $this->l('Increase your sales and profitability thanks to Yuzu accurate targeting platform');
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall the Yuzu integration module?');
		$this->api_url = '//cs.local.yuzu.co';
		$this->yuzu_url = 'http:'.$this->api_url;
		$this->merchant_key = Configuration::get(YUZU_MERCHANT_KEY);
		$this->secret_key = Configuration::get(YUZU_SECRET_KEY);

		if (_PS_VERSION_ < '1.5')
		{
			require_once(_PS_MODULE_DIR_.$this->name.'/backward_compatibility/backward.php');
			$this->template_prefix = 'views/templates/hook/';
		}
	}

	public function isConfigured()
	{
		if (!$this->merchant_key)
			return false;

		return true;
	}

	public function install()
	{
		// configuration
		Configuration::updateValue(YUZU_DISPLAY_ORDER_DETAIL, '1');
		Configuration::updateValue(YUZU_DISPLAY_CHECKOUT_SUCCESS, '1');
		Configuration::updateValue(YUZU_CSS_ADD_TO_CART_PRODUCT, '#add_to_cart input');

		// enable web service
		if (!Configuration::get('PS_WEBSERVICE'))
		{
			Configuration::updateValue('PS_WEBSERVICE', 1);
			Tools::generateHtaccess();
		}

		$this->fixOldVersions();

		if (_PS_VERSION_ < '1.5')
		{
			return parent::install()
			&& $this->registerHook('header')
			&& $this->registerHook('productfooter')
			&& $this->registerHook('home')
			&& $this->registerHook('productActions')
			&& $this->registerHook('footer')
			&& $this->registerHook('orderDetailDisplayed')
			&& $this->registerHook('orderConfirmation')
			&& $this->registerHook('shoppingCart');
			//&& $this->registerHook('newOrder');
		}
		else
		{
			return parent::install()
			&& $this->registerHook('displayHeader')
			&& $this->registerHook('displayFooterProduct')
			&& $this->registerHook('displayOrderDetail')
			&& $this->registerHook('displayOrderConfirmation')
			&& $this->registerHook('displayFooter')
			&& $this->registerHook('displayHome')
			&& $this->registerHook('displayProductButtons')
			&& $this->registerHook('displayShoppingCartFooter');
			//&& $this->registerHook('actionValidateOrder');
		}
	}

	public function uninstall()
	{
		Configuration::deleteByName(YUZU_MERCHANT_KEY);
		Configuration::deleteByName(YUZU_SECRET_KEY);
		Configuration::deleteByName(YUZU_CSS_ADD_TO_CART_PRODUCT);
		Configuration::deleteByName(YUZU_DISPLAY_ORDER_DETAIL);
		Configuration::deleteByName(YUZU_DISPLAY_CHECKOUT_SUCCESS);

		$web_service_key = $this->findAccountByKey($this->secret_key);

		return parent::uninstall() && $web_service_key->delete();
	}

	public function getContent()
	{
		$output = null;

		if (!Configuration::get('PS_WEBSERVICE'))
			$output .= $this->adminDisplayWarning('Web Service must be enabled for Yuzu synchronisation.');

		if (Tools::isSubmit('submit'.$this->name))
		{
			$yuzu_api_key = (string)Tools::getValue(YUZU_MERCHANT_KEY);
			$yuzu_secret_key = (string)Tools::getValue(YUZU_SECRET_KEY);
			$yuzu_css_add_to_cart_product = (string)Tools::getValue(YUZU_CSS_ADD_TO_CART_PRODUCT);
			$yuzu_display_order_detail = (string)Tools::getValue(YUZU_DISPLAY_ORDER_DETAIL);
			$yuzu_display_checkout_success = (string)Tools::getValue(YUZU_DISPLAY_CHECKOUT_SUCCESS);
			if (!$yuzu_api_key || empty($yuzu_api_key))
				$output .= $this->displayError($this->l('Api Key is missing'));
			else if (!$yuzu_secret_key || empty($yuzu_secret_key))
				$output .= $this->displayError($this->l('Secret Key is missing'));
			else
			{
				if (!WebserviceKey::keyExists($yuzu_secret_key))
				{
					$web_service_key = new WebserviceKey();
					$web_service_key->key = $yuzu_secret_key;
					if (!$web_service_key->add())
						$output .= $this->displayError($this->l('Failed to add the Web Service Key.'));

					WebserviceKey::setPermissionForAccount($web_service_key->id, array(
						'carriers' => array('GET' => true),
						'cart_rules' => array('GET' => true, 'PUT' => true, 'POST' => true, 'DELETE' => true),
						'carts' => array('GET' => true),
						'configurations' => array('GET' => true),
						'currencies' => array('GET' => true),
						'groups' => array('GET' => true),
						'guests' => array('GET' => true),
						'manufacturers' => array('GET' => true),
						'order_carriers' => array('GET' => true),
						'order_details' => array('GET' => true),
						'order_discounts' => array('GET' => true),
						'order_histories' => array('GET' => true),
						'order_invoices' => array('GET' => true),
						'order_payments' => array('GET' => true),
						'order_states' => array('GET' => true),
						'product_options' => array('GET' => true),
						'product_suppliers' => array('GET' => true),
						'specific_price_rules' => array('GET' => true),
						'specific_prices' => array('GET' => true),
						'stock_availables' => array('GET' => true),
						'stocks' => array('GET' => true),
						'zones' => array('GET' => true),
						'addresses' => array('GET' => true),
						'categories' => array('GET' => true),
						'countries' => array('GET' => true),
						'customers' => array('GET' => true),
						'languages' => array('GET' => true),
						'orders' => array('GET' => true),
						'products' => array('GET' => true),
						'states' => array('GET' => true)
					));
				}

				Configuration::updateValue(YUZU_MERCHANT_KEY, $yuzu_api_key);
				Configuration::updateValue(YUZU_SECRET_KEY, $yuzu_secret_key);
				Configuration::updateValue(YUZU_CSS_ADD_TO_CART_PRODUCT, $yuzu_css_add_to_cart_product);
				Configuration::updateValue(YUZU_DISPLAY_ORDER_DETAIL, $yuzu_display_order_detail);
				Configuration::updateValue(YUZU_DISPLAY_CHECKOUT_SUCCESS, $yuzu_display_checkout_success);
				$output .= $this->displayConfirmation($this->l('Settings successfully updated'));
			}
		}

		return $output.$this->fixOldVersions(true).$this->displayForm();
	}

	private function fixOldVersions($display = false)
	{
		// Fix webservice
		if (_PS_VERSION_ == '1.4.9.0')
		{
			$path = dirname(__FILE__).'/../../classes/WebserviceRequest.php';
			$file = Tools::file_get_contents($path);

			if (strpos($file, "if (\$this->urlFragments['schema'] == 'synopsis')"))
			{
				if (is_writable($path))
				{
					$file = str_replace("if (\$this->urlFragments['schema'] == 'synopsis')", "if (isset(\$this->urlFragments['schema']) && \$this->urlFragments['schema'] == 'synopsis')", $file);
					@file_put_contents($path, $file);
				}
				else
				{
					if ($display)
						return $this->context->smarty->fetch($this->template_directory.'warning_1490.tpl');
				}
			}
		}
	}

	public function displayForm()
	{
		if (_PS_VERSION_ < '1.5')
		{
			$this->context->smarty->assign('yuzuApiKey', Configuration::get('YUZU_MERCHANT_KEY'));
			$this->context->smarty->assign('yuzuSecretKey', Configuration::get('YUZU_SECRET_KEY'));
			$this->context->smarty->assign('yuzuCssAddToCartProduct', Configuration::get('YUZU_CSS_ADD_TO_CART_PRODUCT'));
			$this->context->smarty->assign('yuzuDisplayOrderDetail', Configuration::get('YUZU_DISPLAY_ORDER_DETAIL'));
			$this->context->smarty->assign('yuzuDisplayCheckoutSuccess', Configuration::get('YUZU_DISPLAY_CHECKOUT_SUCCESS'));
			return $this->context->smarty->fetch($this->template_directory.'configuration.tpl');
		}
		else
		{
			// Get default language
			$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

			// Init Fields form array
			$fields_form = array();
			$fields_form[0]['form'] = array(
				'legend' => array(
					'title' => $this->l('Settings'),
				),
				'input' => array(
					array(
						'type' => 'text',
						'label' => $this->l('Yuzu Api Key'),
						'desc' => "Don't have your API key yet? <br><strong><a href='https://my.yuzu.co/register?from=prestashop'
									target='_blank'>Create your Yuzu account in minutes!</a></strong>",
						'name' => YUZU_MERCHANT_KEY,
						'size' => 40,
						'required' => true
					),
					array(
						'type' => 'text',
						'label' => $this->l('Yuzu Secret Key'),
						'name' => YUZU_SECRET_KEY,
						'desc' => 'Your Yuzu Secret Key provided in my.yuzu.co',
						'size' => 40,
						'required' => true
					),
					array(
						'type' => 'select',
						'label' => $this->l('Display offers in order detail'),
						'name' => YUZU_DISPLAY_ORDER_DETAIL,
						'required' => false,
						'options' => array(
							'query' => array(
								array(
									'id_option' => 1,
									'name' => 'Yes'
								),
								array(
									'id_option' => 0,
									'name' => 'No'
								),
							),
							'id' => 'id_option',
							'name' => 'name'
						)
					),
					array(
						'type' => 'select',
						'label' => $this->l('Display offers in checkout success'),
						'name' => YUZU_DISPLAY_CHECKOUT_SUCCESS,
						'required' => false,
						'options' => array(
							'query' => array(
								array(
									'id_option' => 1,
									'name' => 'Yes'
								),
								array(
									'id_option' => 0,
									'name' => 'No'
								),
							),
							'id' => 'id_option',
							'name' => 'name'
						)
					),
					array(
						'type' => 'text',
						'label' => $this->l('CSS selector: Product - add to cart'),
						'name' => YUZU_CSS_ADD_TO_CART_PRODUCT,
						'size' => 40,
						'required' => false
					)
				),
				'submit' => array(
					'title' => $this->l('Save'),
					'class' => 'button'
				)
			);

			$helper = new HelperForm();

			// Module, token and currentIndex
			$helper->module = $this;
			$helper->name_controller = $this->name;
			$helper->token = Tools::getAdminTokenLite('AdminModules');
			$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

			// Language
			$helper->default_form_language = $default_lang;
			$helper->allow_employee_form_lang = $default_lang;

			// Title and toolbar
			$helper->title = $this->displayName;
			$helper->show_toolbar = true;        // false -> remove toolbar
			$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
			$helper->submit_action = 'submit'.$this->name;
			$helper->toolbar_btn = array(
				'save' =>
					array(
						'desc' => $this->l('Save'),
						'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
							'&token='.Tools::getAdminTokenLite('AdminModules'),
					),
				'back' => array(
					'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
					'desc' => $this->l('Back to list')
				)
			);

			// Load current value
			$helper->fields_value[YUZU_MERCHANT_KEY] = Configuration::get(YUZU_MERCHANT_KEY);
			$helper->fields_value[YUZU_SECRET_KEY] = Configuration::get(YUZU_SECRET_KEY);
			$helper->fields_value[YUZU_CSS_ADD_TO_CART_PRODUCT] = Configuration::get(YUZU_CSS_ADD_TO_CART_PRODUCT);
			$helper->fields_value[YUZU_DISPLAY_ORDER_DETAIL] = Configuration::get(YUZU_DISPLAY_ORDER_DETAIL);
			$helper->fields_value[YUZU_DISPLAY_CHECKOUT_SUCCESS] = Configuration::get(YUZU_DISPLAY_CHECKOUT_SUCCESS);

			return $helper->generateForm($fields_form);
		}
	}

	private function findAccountByKey()
	{
		$id = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT `id_webservice_account`
			FROM '._DB_PREFIX_.'webservice_account
			WHERE `key` = \''.pSQL($this->secret_key).'\'');
		return new WebserviceKey($id);
	}

	private function address(Address $address)
	{
		$state = new State($address->id_state);
		$country = new Country($address->id_country);
		return array(
			'firstName' => $address->firstname,
			'lastName' => $address->lastname,
			'company' => $address->company,
			'street' => array($address->address1, $address->address2),
			'postalCode' => $address->postcode,
			'city' => $address->city,
			'state' => $state->iso_code,
			'country' => $country->iso_code,
		);
	}

	private function getYuzuL10n()
	{
		return array(
			'country' => $this->context->country->iso_code,
			'language' => $this->context->language->iso_code,
			'currency' => $this->context->currency->iso_code
		);
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookHeader()
	{
		return $this->hookDisplayHeader();
	}

	public function hookDisplayHeader()
	{
		if (!$this->isConfigured())
			return false;

		$this->context->smarty->assign(array(
			'yuzu_merchant_key' => $this->merchant_key,
			'yuzu_api_url' => $this->api_url,
			'yuzu_customer_id' => (string)$this->context->customer->id,
			'yuzu_l10n' => Tools::jsonEncode($this->getYuzuL10n())
		));

		return $this->display(__FILE__, $this->template_prefix.'head.tpl');
	}


	/**
	 * Fix for PS 1.4
	 */
	public function hookShoppingCart($params)
	{
		return $this->hookDisplayShoppingCartFooter($params);
	}

	public function hookDisplayShoppingCartFooter($params)
	{
		if (!$this->isConfigured())
			return false;

		$cart = array(
			'id' => (string)$params['cart']->id,
			'subtotal' => (string)$params['total_products'],
			'total' => (string)$params['total_price'],
		);

		$cart['lines'] = array();
		foreach ($params['products'] as $line)
		{
			$cart['lines'][] = array(
				'productId' => (string)$line['id_product'],
				'productAttributeId' => (string)$line['id_product_attribute'],
				'quantity' => (int)$line['quantity'],
				'price' => (float)$line['price']
			);
		}

		$this->context->smarty->assign(array(
				'yuzu_type' => 'cart',
				'yuzu_action' => 'display',
				'yuzu_data' => Tools::jsonEncode($cart)
		));

		return $this->display(__FILE__, $this->template_prefix.'tag.tpl');
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookProductfooter($params)
	{
		return $this->hookDisplayFooterProduct($params);
	}

	public function hookDisplayFooterProduct($params)
	{
		if (!$this->isConfigured())
			return false;

		$this->context->smarty->assign(array(
				'yuzu_type' => 'product',
				'yuzu_action' => 'display',
				'yuzu_data' => Tools::jsonEncode(array(
					'id' => (string)$params['product']->id))
		));
		return $this->display(__FILE__, $this->template_prefix.'tag.tpl');
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookOrderDetailDisplayed($params)
	{
		return $this->hookDisplayOrderDetail($params);
	}

	public function hookDisplayOrderDetail($params)
	{
		if (!$this->isConfigured())
			return false;

		if (!Configuration::get('YUZU_DISPLAY_ORDER_DETAIL'))
			return false;

		$this->context->smarty->assign(array(
			'yuzu_order_id' => (string)$params['order']->id,
			'yuzu_customer_id' => (string)$params['order']->id_customer
		));

		return $this->display(__FILE__, $this->template_prefix.'displayOrderDetail.tpl');
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookOrderConfirmation($params)
	{
		$customer = $this->context->customer;
		switch ($customer->id_gender)
		{
			case 1:
				$gender = 'M';
				break;
			case 2:
				$gender = 'F';
				break;
			default:
				$gender = '';
				break;
		}
		$customer->gender = $gender;

		return $this->hookDisplayOrderConfirmation($params, $customer);
	}

	public function hookDisplayOrderConfirmation($params, $customer = false)
	{
		if (!$this->isConfigured())
			return false;

		if (!Configuration::get('YUZU_DISPLAY_CHECKOUT_SUCCESS'))
			return false;

		if (!$customer)
		{
			$customer = $params['objOrder']->getCustomer();
			$gender = null;
			$gender_obj = new Gender($customer->id_gender);
			switch ($gender_obj->type)
			{
				case 0:
					$gender = 'M';
					break;
				case 1:
					$gender = 'F';
					break;
			}
			$customer->gender = $gender;
		}

		$l10n = $this->getYuzuL10n();

		$delivery_address = $this->address(new Address($params['objOrder']->id_address_delivery));
		$invoice_address = $this->address(new Address($params['objOrder']->id_address_invoice));

		$order = array(
			'id' => (string)$params['objOrder']->id,
			'discount' => (float)$params['objOrder']->total_discounts,
			'subtotal' => (float)$params['objOrder']->total_products,
			'shipping' => (float)$params['objOrder']->total_shipping,
			'tax' => null,
			'total' => (float)$params['objOrder']->total_paid,
			'currency' => $params['currencyObj']->iso_code,
			'shippingMethod' => null,
			'paymentType' => $params['objOrder']->payment,
			'deliveryAddress' => $delivery_address,
			'invoiceAddress' => $invoice_address,
			'creationDate' => date('c', strtotime((string)$params['objOrder']->date_add)),
			'updateDate' => date('c', strtotime((string)$params['objOrder']->date_upd)),
			'customer' => array(
				'id' => (string)$customer->id,
				'lastName' => $customer->lastname,
				'firstName' => $customer->firstname,
				'email' => $customer->email,
				'acceptsMarketing' => $customer->optin ? true : false,
				'gender' => $customer->gender,
				'birthday' => $customer->birthday != '0000-00-00' ? $customer->birthday : null,
				'language' => $l10n['language'],
				'addresses' => array($invoice_address, $delivery_address),
				'creationDate' => date('c', strtotime((string)$customer->date_add)),
				'updateDate' => date('c', strtotime((string)$customer->date_upd))
			));
		$order['lines'] = array();
		foreach ($params['objOrder']->getProducts() as $line)
		{
			$order['lines'][] = array(
				'productId' => (string)$line['product_id'],
				'productAttributeId' => (string)$line['product_attribute_id'],
				'quantity' => (int)$line['product_quantity'],
				'price' => (float)$line['total_price']
			);
		}

		$this->context->smarty->assign(array(
			'yuzu_type' => 'order',
			'yuzu_action' => 'display',
			'yuzu_data' => Tools::jsonEncode($order),
			'yuzu_order_id' => $order['id']
		));
		return $this->display(__FILE__, $this->template_prefix.'displayOrderConfirmation.tpl');
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookFooter()
	{
		if (Tools::getValue('id_category'))
		{
			$this->context->smarty->assign(array(
					'yuzu_type' => 'category',
					'yuzu_action' => 'display',
					'yuzu_data' => Tools::jsonEncode(array(
						'id' => (string)Tools::getValue('id_category')))
			));
			return $this->display(__FILE__, $this->template_prefix.'tag.tpl');
		}
	}

	public function hookDisplayFooter()
	{
		if (!$this->isConfigured())
			return false;

		if ($this->context->controller instanceof CategoryController)
		{
			$this->context->smarty->assign(array(
					'yuzu_type' => 'category',
					'yuzu_action' => 'display',
					'yuzu_data' => Tools::jsonEncode(array(
						'id' => (string)$this->context->controller->getCurrentCategory()->id))
				));
			return $this->display(__FILE__, $this->template_prefix.'tag.tpl');
		}
		return null;
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookHome()
	{
		return $this->hookDisplayHome();
	}

	public function hookDisplayHome()
	{
		if (!$this->isConfigured())
			return false;

		$this->context->smarty->assign(array(
				'yuzu_type' => 'home',
				'yuzu_action' => 'display',
				'yuzu_data' => Tools::jsonEncode(null)
		));
		return $this->display(__FILE__, $this->template_prefix.'tag.tpl');
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookProductActions($params)
	{
		return $this->hookDisplayProductButtons($params);
	}

	public function hookDisplayProductButtons($params)
	{
		if (!$this->isConfigured())
			return false;

		$this->context->smarty->assign(array(
				'yuzu_product_id' => (string)$params['product']->id,
				YUZU_CSS_ADD_TO_CART_PRODUCT => Configuration::get(YUZU_CSS_ADD_TO_CART_PRODUCT)
		));

		return $this->display(__FILE__, $this->template_prefix.'displayProductButtons.tpl');
	}

	/**
	 * Fix for PS 1.4
	 */
	public function hookNewOrder($params)
	{
		return $this->hookActionValidateOrder($params);
	}

	/**
	 * Hook disabled in v1.0.0
	 * @param $params
	 */
	public function hookActionValidateOrder($params)
	{
		if (!$this->isConfigured())
			return false;

		$order = $params['order'];
		$customer = $params['customer'];

		$url_link = $this->yuzu_url.'/click/'.Configuration::get(YUZU_MERCHANT_KEY).'/'.$customer->id.'/'.$order->id.'/';
		$img_link = $this->yuzu_url.'/ban/'.Configuration::get(YUZU_MERCHANT_KEY).'/'.$customer->id.'/'.$order->id.'/';

		$offers = <<<EOL
<tr>
	<td colspan="8" align="center" style="padding: 10px;">
		<a href="{$url_link}0">
			<img src="{$img_link}0.png" alt="offer 0"/>
		</a>
		<table cellspacing="0" cellpadding="0" style="width: 100%; margin-top: 10px;">
			<tr>
				<td align="center"><a href="{$url_link}1"><img src="{$img_link}1.png" alt="offer 1"/></a></td>
				<td align="center"><a href="{$url_link}2"><img src="{$img_link}2.png" alt="offer 2"/></a></td>
			</tr>
			<tr>
				<td align="center"><a href="{$url_link}3"><img src="{$img_link}3.png" alt="offer 3"/></a></td>
				<td align="center"><a href="{$url_link}4"><img src="{$img_link}4.png" alt="offer 4"/></a></td>
			</tr>
		</table>
	</td>
</tr>
EOL;

		Mail::Send((int)$order->id_lang,
			'order_offers',
			Mail::l('A thankfull reward for your purchase...', (int)$order->id_lang),
			array('{offers}' => $offers),
			$customer->email,
			$customer->firstname.' '.$customer->lastname,
			null,
			null,
			null,
			null, dirname(__FILE__).'/mails/', false, (int)$order->id_shop);
	}
}