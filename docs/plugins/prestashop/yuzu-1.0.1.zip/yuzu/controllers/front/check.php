<?php
/**
 * The MIT License (MIT)
 *
 * Copyright (c) 2014-2015 Yuzu
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author    Jonathan Martin <jonathan@yuzu.co>
 * @copyright 2014-2015 Yuzu
 * @license   MIT Licence
 */

if (!defined('_PS_VERSION_'))
	exit;

class YuzuCheckModuleFrontController extends ModuleFrontController
{
	public function initContent()
	{
		$merchant_key = Configuration::get(YUZU_MERCHANT_KEY);
		$secret_key = Configuration::get(YUZU_SECRET_KEY);
		$in_checkout = Configuration::get(YUZU_DISPLAY_CHECKOUT_SUCCESS);
		$in_order_view = Configuration::get(YUZU_DISPLAY_ORDER_DETAIL);

		$module = Module::getInstanceByName('yuzu');

		$response = array(
			'version' => $module->version,
			'ps_version' => _PS_VERSION_,
			'php_version' => phpversion(),
			'merchant_key' => ($merchant_key) ? true : false,
			'secret_key' => ($secret_key) ? true : false,
			'in_checkout' => ($in_checkout) ? true : false,
			'in_order_view' => ($in_order_view) ? true : false,
			'enabled' => true
		);

		echo Tools::jsonEncode($response);
		exit();
	}
}